import axios from 'axios';
const api = axios.create({baseURL: import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000/api/v1', timeout:30000});
api.interceptors.request.use(c=>{const t=localStorage.getItem('pactelle_token');if(t)c.headers.Authorization=`Bearer ${t}`;return c;});
api.interceptors.response.use(r=>r,e=>{if(e.response?.status===401){localStorage.removeItem('pactelle_token');localStorage.removeItem('pactelle_session');if(!['/login','/register'].includes(location.pathname))location.href='/login';}return Promise.reject(e);});
export const message=(e:unknown)=>axios.isAxiosError(e)?(typeof e.response?.data?.detail==='string'?e.response.data.detail:e.message):e instanceof Error?e.message:'Request failed';
export const apiCall={
 login:(email:string,password:string)=>api.post('/auth/login',{email,password}).then(r=>r.data),
 register:(p:object)=>api.post('/auth/register',p).then(r=>r.data),
 dashboard:(org:string)=>api.get(`/organizations/${org}/dashboard`).then(r=>r.data),
 contracts:(org:string)=>api.get(`/contracts/organizations/${org}`).then(r=>r.data),
 createContract:(org:string,p:object)=>api.post(`/contracts/organizations/${org}`,p).then(r=>r.data),
 upload:(id:string,file:File)=>{const f=new FormData();f.append('file',file);return api.post(`/documents/upload/${id}`,f).then(r=>r.data);},
 process:(id:string)=>api.post(`/documents/${id}/process`).then(r=>r.data),
 findings:(org:string)=>api.get(`/organizations/${org}/portfolio-findings`,{params:{page:1,page_size:100}}).then(r=>r.data),
 analyse:(org:string)=>api.post(`/organizations/${org}/portfolio-analysis`).then(r=>r.data),
 findingStatus:(org:string,id:string,status:string)=>api.patch(`/organizations/${org}/portfolio-findings/${id}/status`,{status}).then(r=>r.data),
 actions:(org:string)=>api.get(`/organizations/${org}/portfolio-actions`,{params:{page:1,page_size:100}}).then(r=>r.data),
 actionStatus:(org:string,id:string,status:string)=>api.patch(`/organizations/${org}/portfolio-actions/${id}/status`,{status}).then(r=>r.data),
 obligations:(org:string)=>api.get(`/organizations/${org}/obligations`,{params:{page:1,page_size:100}}).then(r=>r.data),
 syncObligations:(org:string)=>api.post(`/organizations/${org}/obligations/sync`).then(r=>r.data),
 obligationStatus:(org:string,id:string,p:object)=>api.patch(`/organizations/${org}/obligations/${id}`,p).then(r=>r.data),
 members:(org:string)=>api.get(`/organizations/${org}/members`).then(r=>r.data),
};
